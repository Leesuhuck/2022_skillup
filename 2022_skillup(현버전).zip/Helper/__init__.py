from Helper.AutoBaseFunction import AutomationFunctionDecorator

__all__ = [
    'AutomationFunctionDecorator'
]